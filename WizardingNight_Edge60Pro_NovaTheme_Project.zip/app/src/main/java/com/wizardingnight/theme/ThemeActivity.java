package com.wizardingnight.theme;

import android.app.Activity;
import android.os.Bundle;

/** Theme container activity. Nova Launcher reads the theme intent-filter and resources. */
public class ThemeActivity extends Activity {
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        finish();
    }
}
