# Wizarding Night — Motorola Edge 60 Pro / Nova Launcher Theme

A personal-use, Hogwarts-inspired dark wizarding theme package for Nova Launcher.

## Device target
Motorola Edge 60 Pro: 1220 × 2712 display.

## Included
- 1220×2712 portrait wallpaper
- 29 custom gold-engraved icon assets
- Nova `appfilter.xml` mappings
- Nova manual icon picker list
- Nova wallpaper registration
- Dock pattern
- Android Studio project ready to build into an APK

## Build the installable APK
1. Install Android Studio on a computer.
2. Open this folder as an existing project.
3. Let Gradle sync/download the Android Gradle Plugin and SDK 35.
4. Build > Build APK(s).
5. Install the resulting `app-debug.apk` on your phone.
6. Install Nova Launcher.
7. Nova Settings > Look & feel > Icon theme > choose **Wizarding Night**.
8. Nova Settings > Backup & restore > save your Nova setup after arranging the home screen.
9. Apply `wallpaper_wizarding_night.png` as Home + Lock wallpaper.

## Important
This is a Nova Launcher theme, not a Motorola system firmware theme. Nova documents theme support through the `com.novalauncher.THEME` intent and `res/xml/appfilter.xml`.

The app mappings are based on common package/activity names. Some apps or regional variants may use different activities; those can be added to `appfilter.xml`.

## Design
The visual language is wizarding-night: midnight blue/black, antique gold, engraved medallions, parchment accents, candlelight, stars and magical glyphs. It intentionally uses original wizarding-inspired artwork rather than copying official movie assets.
